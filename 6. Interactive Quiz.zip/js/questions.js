
let questions = [
       {
    numb: 1,
    question: "What is the first step in the entrepreneurial process?",
    answer: "Idea generation",
    options: [
      "Idea generation",
      "Market research",
      "Business planning",
      " Product development"
    ]
  },


    {
    numb: 2,
    question: "Which of the following is NOT a characteristic of successful entrepreneurs? ",
    answer: "Procrastination",
    options: [
      "Risk-taking",
      "Procrastination",
      "Persistence",
      "Innovation"
    ]
  },

  {
    numb: 3,
    question: "What is the term used to describe the process of turning an idea into a viable business?",
    answer: "Commercialization",
    options: [
      "Innovation",
      "Commercialization",
      "Monetization",
      "Capitalization"
    ]
  },


  {
    numb: 4,
    question: "What is the primary purpose of a business plan?",
    answer: "All of the above",
    options: [
      "To secure funding",
      "To outline the company's mission and vision",
      "To provide a roadmap for the business",
      "All of the above"
    ]
  },


  {
    numb: 5,
    question: "What does ROI stand for in the context of entrepreneurship?",
    answer: "Return on Investment",
    options: [
      "Return on Investment",
      "Revenue of Income",
      "Risk of Investment",
      "Ratio of Income"
    ]
  },


];